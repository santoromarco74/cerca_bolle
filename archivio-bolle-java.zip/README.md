# Archivio Bolle — versione Java

Indicizza bolle/DDT scansionati (TIF/PDF) con OCR e le rende ricercabili
per descrizione articolo da una pagina web. Stesso `bolle.db` (SQLite FTS5)
della versione Python: i due programmi sono interscambiabili sullo stesso archivio.

## Requisiti
- Java 17 o superiore (JDK per compilare, JRE per eseguire)
- Maven (solo per compilare)
- Tesseract OCR con lingua italiana:
  Windows -> installer UB Mannheim (https://github.com/UB-Mannheim/tesseract/wiki),
  spuntare "Italian" tra le lingue aggiuntive.
  Il programma lo cerca nel PATH e nei percorsi di installazione tipici.

## Compilazione
    mvn package
Produce `target/archivio-bolle.jar` (jar unico, autosufficiente).

## Avvio
    java -jar target/archivio-bolle.jar          # porta 8000
    java -jar target/archivio-bolle.jar 9090     # porta a scelta

Poi aprire http://localhost:8000
- ricerca per riga articolo (esatta + fuzzy tollerante ai typo/errori OCR)
- ricerca su tutto il documento
- caricamento drag&drop, visualizzatore pagine integrato, download originale

Il database `bolle.db` e la cartella `archivio_bolle/` vengono creati
nella directory da cui si lancia il jar.
